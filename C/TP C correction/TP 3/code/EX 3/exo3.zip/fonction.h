#pragma once


void initialiseTab(float *tab, int taille);											//initialise le tableau en paramettre a -2

float moyenne(float *tab, int taille);												//retourne la moyenne d'un tableau de flotant

double ecartType(float *tab, int tailleTab, float moyenne);							//retourne l'�cart type d'un tableau de flotant 

int maisTPasLaMaisTOu(float *tab, int taille);										//retourne le nombre de -1 dans un tableau 

void sortTab(float *tab1, float *tab2, float *tmp, int *position, int taille);		//On copier le premier tableau dans le deuxi�me et on tri le deuxi�me, on retourne aussi le tableau de position

float minTab(float *tab, int taille);												//retourne le min d'un tableau

float maxTab(float *tab, int taille);												//retourne le max d'un tableau

void afficherTab(float *tab, int *position, int taille);

void bye(void);